# CSS :has OS Dock with CSS Trigonometric Functions 🤙

A Pen created on CodePen.io. Original URL: [https://codepen.io/jh3y/pen/GRwwWoV](https://codepen.io/jh3y/pen/GRwwWoV).

